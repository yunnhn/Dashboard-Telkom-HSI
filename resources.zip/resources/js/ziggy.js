const Ziggy = {
    url: "http:\/\/127.0.0.1:8000",
    port: 8000,
    defaults: {},
    routes: {
        "sanctum.csrf-cookie": {
            uri: "sanctum\/csrf-cookie",
            methods: ["GET", "HEAD"],
        },
        "google.drive.test": {
            uri: "google-drive-test",
            methods: ["GET", "HEAD"],
        },
        dashboard: { uri: "dashboard", methods: ["GET", "HEAD"] },
        dashboardDigitalProduct: {
            uri: "dashboardDigitalProduct",
            methods: ["GET", "HEAD"],
        },
        "profile.edit": { uri: "profile", methods: ["GET", "HEAD"] },
        "profile.update": { uri: "profile", methods: ["PATCH"] },
        "profile.destroy": { uri: "profile", methods: ["DELETE"] },
        "data-report.index": { uri: "data-report", methods: ["GET", "HEAD"] },
        "data-report.export": { uri: "data-report\/export", methods: ["POST"] },
        "data-report.exportInProgress": {
            uri: "data-report\/export\/inprogress",
            methods: ["POST"],
        },
        "galaksi.index": { uri: "galaksi", methods: ["GET", "HEAD"] },
        "traceroute.run": { uri: "run-traceroute", methods: ["POST"] },
        "import.progress": {
            uri: "import-progress\/{batchId}",
            methods: ["GET", "HEAD"],
            parameters: ["batchId"],
        },
        "admin.analysisDigitalProduct.index": {
            uri: "admin\/analysis-digital-product",
            methods: ["GET", "HEAD"],
        },
        "admin.analysisDigitalProduct.upload": {
            uri: "admin\/analysis-digital-product\/upload",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.targets": {
            uri: "admin\/analysis-digital-product\/targets",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.uploadComplete": {
            uri: "admin\/analysis-digital-product\/upload-complete",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.uploadCancel": {
            uri: "admin\/analysis-digital-product\/upload-cancel",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.saveConfig": {
            uri: "admin\/analysis-digital-product\/config",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.resetConfig": {
            uri: "admin\/analysis-digital-product\/reset-config",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.clearHistory": {
            uri: "admin\/analysis-digital-product\/clear-history",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.export.report": {
            uri: "admin\/analysis-digital-product\/export-report",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.saveCustomTargets": {
            uri: "admin\/analysis-digital-product\/custom-targets",
            methods: ["POST"],
        },
        "admin.analysisDigitalProduct.export.kpiPo": {
            uri: "admin\/analysis-digital-product\/export\/kpi-po",
            methods: ["GET", "HEAD"],
        },
        "admin.analysisDigitalProduct.export.inprogress": {
            uri: "admin\/analysis-digital-product\/export\/inprogress",
            methods: ["GET", "HEAD"],
        },
        "admin.analysisDigitalProduct.export.history": {
            uri: "admin\/analysis-digital-product\/export\/history",
            methods: ["GET", "HEAD"],
        },
        "admin.analysisDigitalProduct.admin.analysisDigitalProduct.updateNetPrice":
            {
                uri: "admin\/analysis-digital-product\/update-net-price\/{order_id}",
                methods: ["PUT"],
                parameters: ["order_id"],
            },
        "admin.analysisSOS.index": {
            uri: "admin\/analysis-sos",
            methods: ["GET", "HEAD"],
        },
        "admin.manual.update.complete": {
            uri: "admin\/manual-update\/complete\/{documentData}",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.manual.update.cancel": {
            uri: "admin\/manual-update\/cancel\/{documentData}",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.complete.update.progress": {
            uri: "admin\/complete-update\/progress\/{documentData}",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.complete.update.qc": {
            uri: "admin\/complete-update\/qc\/{documentData}",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.complete.update.cancel": {
            uri: "admin\/complete-update\/cancel\/{documentData}",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.qc.update.progress": {
            uri: "admin\/qc-update\/{documentData}\/progress",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.qc.update.done": {
            uri: "admin\/qc-update\/{documentData}\/done",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.qc.update.cancel": {
            uri: "admin\/qc-update\/{documentData}\/cancel",
            methods: ["PUT"],
            parameters: ["documentData"],
            bindings: { documentData: "order_id" },
        },
        "admin.account-officers.store": {
            uri: "admin\/account-officers",
            methods: ["POST"],
        },
        "admin.account-officers.update": {
            uri: "admin\/account-officers\/{account_officer}",
            methods: ["PUT", "PATCH"],
            parameters: ["account_officer"],
        },
        "admin.merge-excel.create": {
            uri: "admin\/merge-excel",
            methods: ["GET", "HEAD"],
        },
        "admin.merge-excel.merge": {
            uri: "admin\/merge-excel",
            methods: ["POST"],
        },
        "admin.merge-excel.download": {
            uri: "admin\/merge-excel\/download",
            methods: ["GET", "HEAD"],
        },
        "admin.merge-excel.download-url": {
            uri: "admin\/merge-excel\/download-url",
            methods: ["GET", "HEAD"],
        },
        "users.index": { uri: "users", methods: ["GET", "HEAD"] },
        "users.create": { uri: "users\/create", methods: ["GET", "HEAD"] },
        "users.store": { uri: "users", methods: ["POST"] },
        "users.show": {
            uri: "users\/{user}",
            methods: ["GET", "HEAD"],
            parameters: ["user"],
        },
        "users.edit": {
            uri: "users\/{user}\/edit",
            methods: ["GET", "HEAD"],
            parameters: ["user"],
            bindings: { user: "id" },
        },
        "users.update": {
            uri: "users\/{user}",
            methods: ["PUT", "PATCH"],
            parameters: ["user"],
            bindings: { user: "id" },
        },
        "users.destroy": {
            uri: "users\/{user}",
            methods: ["DELETE"],
            parameters: ["user"],
            bindings: { user: "id" },
        },
        register: { uri: "register", methods: ["GET", "HEAD"] },
        login: { uri: "login", methods: ["GET", "HEAD"] },
        "password.request": {
            uri: "forgot-password",
            methods: ["GET", "HEAD"],
        },
        "password.email": { uri: "forgot-password", methods: ["POST"] },
        "password.reset": {
            uri: "reset-password\/{token}",
            methods: ["GET", "HEAD"],
            parameters: ["token"],
        },
        "password.store": { uri: "reset-password", methods: ["POST"] },
        "verification.notice": {
            uri: "verify-email",
            methods: ["GET", "HEAD"],
        },
        "verification.verify": {
            uri: "verify-email\/{id}\/{hash}",
            methods: ["GET", "HEAD"],
            parameters: ["id", "hash"],
        },
        "verification.send": {
            uri: "email\/verification-notification",
            methods: ["POST"],
        },
        "password.confirm": {
            uri: "confirm-password",
            methods: ["GET", "HEAD"],
        },
        "password.update": { uri: "password", methods: ["PUT"] },
        logout: { uri: "logout", methods: ["POST"] },
        "storage.local": {
            uri: "storage\/{path}",
            methods: ["GET", "HEAD"],
            wheres: { path: ".*" },
            parameters: ["path"],
        },
    },
};
if (typeof window !== "undefined" && typeof window.Ziggy !== "undefined") {
    Object.assign(Ziggy.routes, window.Ziggy.routes);
}
export { Ziggy };

//for CI
