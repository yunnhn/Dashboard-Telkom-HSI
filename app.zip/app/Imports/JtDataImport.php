<?php

namespace App\Imports;

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

// PERHATIKAN: Tanpa WithChunkReading agar Synchronous
class JtDataImport implements ToModel, WithHeadingRow, WithBatchInserts
{
    protected $batchId;
    protected $totalRows;
    protected $currentRow = 0;

    public function __construct(string $batchId, int $totalRows)
    {
        $this->batchId = $batchId;
        $this->totalRows = $totalRows > 0 ? $totalRows : 1;
    }

    public function model(array $row)
    {
        // 1. Update Progress Bar Manual
        ++$this->currentRow;

        if ($this->currentRow % 20 === 0) {
            $percentage = 5 + (($this->currentRow / $this->totalRows) * 90);
            $percentage = min(round($percentage), 98);
            Cache::put('import_progress_'.$this->batchId, $percentage, now()->addHour());
        }

        // 2. Validasi Baris Kosong
        if (empty($row['witel_lama']) && empty($row['segmen']) && empty($row['region']) && empty($row['no_nde_spmk'])) {
            return null;
        }

        // 3. Bersihkan Data
        $witelLama = trim($row['witel_lama'] ?? '');
        $segmen = trim($row['segmen'] ?? '');
        $statusTompsNew = strtolower($row['status_tomps_new'] ?? '');
        $statusProyek = strtolower($row['status_proyek'] ?? '');
        $baDrop = strtolower($row['ba_drop'] ?? '');
        $idIHld = trim($row['id_i_hld'] ?? '');
        $noNdeSpmk = trim($row['no_nde_spmk'] ?? '');

        $tanggalMom = $this->parseDate($row['tanggal_mom'] ?? null);
        $tanggalCb = $this->parseDate($row['tanggal_cb'] ?? null);

        // 4. Logika Bisnis
        $poName = $this->determinePoName($witelLama, $segmen);
        $goLive = (str_contains($statusTompsNew, 'go live') || str_contains($statusProyek, 'go live')) ? 'Y' : 'N';
        $populasiNonDrop = str_contains($baDrop, 'drop') ? 'N' : 'Y';

        $tahunRaw = $row['tahun'] ?? '';
        $tahun = (preg_match('/^[0-9]{4}$/', $tahunRaw)) ? $tahunRaw : null;

        $usia = $tanggalMom ? Carbon::now()->diffInDays(Carbon::parse($tanggalMom)) : null;
        $bulan = isset($row['bulan']) ? substr($row['bulan'], 0, 7) : null;

        // 5. MENENTUKAN KUNCI UNIK (Agar Tidak Double)
        // Prioritas 1: ID i-HLD
        // Prioritas 2: No NDE SPMK
        // Prioritas 3: Uraian Kegiatan + Witel (Fallback terakhir)
        $matchAttributes = [];
        if (!empty($idIHld)) {
            $matchAttributes = ['id_i_hld' => $idIHld];
        } elseif (!empty($noNdeSpmk)) {
            $matchAttributes = ['no_nde_spmk' => $noNdeSpmk];
        } else {
            $matchAttributes = [
                'witel_lama' => $witelLama,
                'uraian_kegiatan' => $row['uraian_kegiatan'] ?? '',
            ];
        }

        // 6. Data yang akan di-update/insert
        $values = [
            'bulan' => $bulan,
            'tahun' => $tahun,
            // 'id_i_hld' & 'no_nde_spmk' sudah ada di matchAttributes atau akan digabung otomatis oleh updateOrInsert
            'id_i_hld' => $idIHld ?: null,
            'no_nde_spmk' => $noNdeSpmk ?: null,
            'region' => $row['region'] ?? null,
            'witel_lama' => $witelLama,
            'witel_baru' => $row['witel_baru'] ?? null,
            'uraian_kegiatan' => $row['uraian_kegiatan'] ?? null,
            'segmen' => $segmen,
            'po_name' => $poName,
            'jenis_kegiatan' => $row['jenis_kegiatan'] ?? null,
            'status_proyek' => $row['status_proyek'] ?? null,
            'go_live' => $goLive,
            'keterangan_toc' => $row['keterangan_toc'] ?? null,
            'tanggal_cb' => $tanggalCb,
            'tanggal_mom' => $tanggalMom,
            'usia' => $usia,
            'revenue_plan' => $this->cleanCurrency($row['revenue_plan'] ?? ''),
            'rab' => $this->cleanCurrency($row['rab'] ?? ''),
            'perihal_nde_spmk' => $row['perihal_nde_spmk'] ?? null,
            'mom' => $row['mom'] ?? null,
            'ba_drop' => $row['ba_drop'] ?? null,
            'populasi_non_drop' => $populasiNonDrop,
            'total_port' => $row['total_port'] ?? null,
            'template_durasi' => $row['template_durasi'] ?? null,
            'toc' => $row['toc'] ?? null,
            'umur_pekerjaan' => $row['umur_pekerjaan'] ?? null,
            'kategori_umur_pekerjaan' => $row['kategori_umur_pekerjaan'] ?? null,
            'status_tomps_last_activity' => $row['status_tomps_last_activity'] ?? null,
            'status_tomps_new' => $row['status_tomps_new'] ?? null,
            'status_i_hld' => $row['status_i_hld'] ?? null,
            'nama_odp_go_live' => $row['nama_odp_go_live'] ?? null,
            'bak' => $row['bak'] ?? null,
            'keterangan_pelimpahan' => $row['keterangan_pelimpahan'] ?? null,
            'mitra_lokal' => $row['mitra_lokal'] ?? null,
            'updated_at' => now(), // Updated at selalu berubah
            'batch_id' => $this->batchId, // Update batch ID ke yang terbaru
        ];

        // Jika record baru, tambahkan created_at
        // updateOrInsert(conditions, values)
        // Laravel secara otomatis menggabungkan conditions & values saat insert.
        // Namun created_at harus kita handle manual jika ingin hanya saat insert.
        // Karena DB::table tidak otomatis handle timestamps Eloquent.

        // Cara Cerdas: Cek eksistensi dulu (sedikit overhead tapi aman) atau hajar updateOrInsert
        // Kita gunakan updateOrInsert langsung. created_at akan NULL jika tidak didefinisikan saat insert.
        // Agar created_at terisi saat insert saja, kita perlu trik atau biarkan null (biasanya database set default CURRENT_TIMESTAMP).
        // Untuk amannya, kita set created_at di $values jika kita tidak peduli overwrite created_at,
        // TAPI jika ingin created_at asli terjaga, logic-nya jadi sedikit panjang.
        // Untuk use case "Update Data Excel", biasanya kita ingin data terbaru, jadi overwrite tidak masalah.
        // Namun, mari kita coba pertahankan created_at lama jika ada.

        $exists = DB::table('spmk_mom')->where($matchAttributes)->first();

        if ($exists) {
            DB::table('spmk_mom')->where('id', $exists->id)->update($values);
        } else {
            $values['created_at'] = now();
            // Merge match attributes agar tersimpan juga
            DB::table('spmk_mom')->insert(array_merge($matchAttributes, $values));
        }

        return null;
    }

    // --- Helper Functions ---

    private function parseDate($dateString)
    {
        if (!$dateString) {
            return null;
        }
        try {
            if (is_numeric($dateString)) {
                return \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($dateString)->format('Y-m-d');
            }

            return Carbon::createFromFormat('d-M-y', $dateString)->format('Y-m-d');
        } catch (\Throwable $e) {
            try {
                return Carbon::parse($dateString)->format('Y-m-d');
            } catch (\Throwable $ex) {
                return null;
            }
        }
    }

    private function cleanCurrency($value)
    {
        if (is_null($value)) {
            return null;
        }
        $cleaned = preg_replace('/[^0-9]/', '', $value);

        return $cleaned === '' ? null : $cleaned;
    }

    private function determinePoName($witel, $segmen)
    {
        $witel = strtoupper(trim($witel));
        $segmen = strtoupper(trim($segmen));

        $directMapping = [
            'WITEL MADIUN' => 'ALFONSUS',
            'WITEL JEMBER' => 'ILHAM MIFTAHUL',
            'WITEL PASURUAN' => 'I WAYAN KRISNA',
            'WITEL SIDOARJO' => 'IBRAHIM MUHAMMAD',
            'WITEL KEDIRI' => 'LUQMAN KURNIAWAN',
            'WITEL MALANG' => 'NURTRIA IMAN',
            'WITEL NTT' => 'MARIA FRANSISKA',
            'WITEL NTB' => 'ANDRE YANA',
        ];

        if (isset($directMapping[$witel])) {
            return $directMapping[$witel];
        }
        if (in_array($witel, ['WITEL DENPASAR', 'WITEL SINGARAJA'])) {
            return 'DIASTANTO';
        }

        if (in_array($witel, ['WITEL SURABAYA UTARA', 'WITEL SURABAYA SELATAN', 'WITEL MADURA'])) {
            if ($segmen === 'DBS') {
                return 'FERIZKA PARAMITHA';
            }
            if ($segmen === 'DGS') {
                return 'EKA SARI';
            }
            if (in_array($segmen, ['DES', 'DSS', 'DPS'])) {
                return 'DWIEKA SEPTIAN';
            }
        }

        return '';
    }

    public function batchSize(): int
    {
        return 500;
    }
}
