import React, { useState, useEffect, useRef } from 'react';
import { Link } from '@inertiajs/react';
import { MdDashboard, MdAssessment, MdKeyboardArrowDown } from 'react-icons/md';
import { FiSettings, FiUser, FiLogOut, FiUsers, FiChevronLeft, FiChevronRight } from 'react-icons/fi';

// Logo beradaptasi dengan status sidebar
const Logo = ({ isSidebarOpen }) => (
    <div className="flex items-center justify-center h-20 border-b border-gray-200 relative overflow-hidden">
        <div className={`transition-opacity duration-200 ${isSidebarOpen ? 'opacity-100' : 'opacity-0'}`}>
            <h1 className="text-2xl font-bold text-red-600">Telkom<span className="text-gray-800">Indonesia</span></h1>
        </div>
        <div className={`absolute transition-opacity duration-200 ${!isSidebarOpen ? 'opacity-100' : 'opacity-0'}`}>
            <img src="/images/logo telkom.jpg" alt="Telkom" className="h-8" />
        </div>
    </div>
);

// NavLink beradaptasi dengan status sidebar
const NavLink = ({ href, active, icon, isSidebarOpen, children }) => (
    <div className="relative group">
        <Link
            href={href}
            className={`flex items-center py-4 text-gray-600 hover:bg-gray-100 transition-colors duration-200 ${isSidebarOpen ? 'px-6' : 'justify-center'} ${active ? 'bg-gray-200 text-gray-800 font-bold' : ''}`}
        >
            {icon}
            <span className={`ml-4 whitespace-nowrap transition-opacity duration-200 ${isSidebarOpen ? 'opacity-100' : 'opacity-0'}`}>
                {children}
            </span>
        </Link>
        {!isSidebarOpen && (
            <div className="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
                {children}
            </div>
        )}
    </div>
);

// UserProfile beradaptasi dengan status sidebar
const UserProfile = ({ user, isSidebarOpen }) => {
    const [isProfileOpen, setIsProfileOpen] = useState(false);
    const profileRef = useRef(null);

    useEffect(() => {
        function handleClickOutside(event) {
            if (profileRef.current && !profileRef.current.contains(event.target)) {
                setIsProfileOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    if (!user) return null;

    return (
        <div className="mt-auto p-2 border-t border-gray-200 relative" ref={profileRef}>
            {isProfileOpen && (
                <div className={`absolute bottom-full mb-2 bg-white rounded-md shadow-lg border py-2 z-20 ${isSidebarOpen ? 'w-[calc(100%-1rem)]' : 'left-full ml-2 w-56'}`}>
                    <div className="px-4 py-3 border-b">
                        <p className="font-bold text-gray-800 truncate">{user.name}</p>
                        <p className="text-sm text-gray-500 truncate">{user.email}</p>
                    </div>
                    <div className="mt-2">
                        {user.role === 'superadmin' && (<Link href={route('users.index')} className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" onClick={() => setIsProfileOpen(false)}><FiUsers className="mr-3" />User Management</Link>)}
                        <Link href={route('profile.edit')} className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" onClick={() => setIsProfileOpen(false)}><FiUser className="mr-3" />Edit Profile</Link>
                        <Link href={route('logout')} method="post" as="button" className="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"><FiLogOut className="mr-3" />Log Out</Link>
                    </div>
                </div>
            )}
            <div
                className={`flex items-center cursor-pointer p-2 rounded-lg hover:bg-gray-100 ${!isSidebarOpen && 'justify-center'}`}
                onClick={() => setIsProfileOpen(!isProfileOpen)}
            >
                <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                    {user.name.charAt(0).toUpperCase()}
                </div>
                <div className={`ml-3 flex-grow overflow-hidden transition-all duration-300 ${isSidebarOpen ? 'w-auto opacity-100' : 'w-0 opacity-0'}`}>
                    <p className="font-semibold text-gray-800 text-sm truncate">{user.name}</p>
                    <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                </div>
            </div>
        </div>
    );
};

// Komponen utama Sidebar menerima props dari layout
export default function Sidebar({ user, isSidebarOpen, toggleSidebar }) {
    const [isDashboardOpen, setIsDashboardOpen] = useState(false);
    const [isReportsOpen, setIsReportsOpen] = useState(false);
    const isDashboardActive = route().current('dashboardDigitalProduct');
    const isReportsActive = route().current('analysisDigitalProduct.index') || route().current('galaksi.index');

    // Menutup dropdown jika sidebar ditutup
    useEffect(() => {
        if (!isSidebarOpen) {
            setIsDashboardOpen(false);
            setIsReportsOpen(false);
        }
    }, [isSidebarOpen]);

    return (
        <div className={`flex flex-col bg-white h-screen fixed shadow-lg z-30 transition-all duration-300 ease-in-out ${isSidebarOpen ? 'w-64' : 'w-20'}`}>
            <button onClick={toggleSidebar} className="absolute -right-3 top-6 z-40 bg-white p-1 rounded-full shadow-md border hover:bg-gray-100 transition-colors">
                {isSidebarOpen ? <FiChevronLeft size={16} /> : <FiChevronRight size={16} />}
            </button>

            <Logo isSidebarOpen={isSidebarOpen} />

            <nav className="flex-grow pt-4 overflow-y-auto overflow-x-hidden">
                {user.role === 'superadmin' && (<NavLink href={route('users.index')} active={route().current('users.*')} icon={<FiUsers size={22} />} isSidebarOpen={isSidebarOpen}>User Management</NavLink>)}

                {(user.role === 'user' || user.role === 'admin') && (
                    <>
                        {/* Dashboard Dropdown */}
                        <div className="relative">
                            <button onClick={() => isSidebarOpen && setIsDashboardOpen(!isDashboardOpen)} className={`w-full flex items-center py-4 text-gray-600 hover:bg-gray-100 transition duration-300 text-left ${isSidebarOpen ? 'px-6' : 'justify-center'} ${isDashboardActive ? 'bg-gray-200 text-gray-800 font-bold' : ''}`}>
                                <MdDashboard size={22} />
                                <span className={`ml-4 whitespace-nowrap transition-opacity duration-200 ${isSidebarOpen ? 'opacity-100' : 'opacity-0'}`}>Dashboard</span>
                                {isSidebarOpen && <MdKeyboardArrowDown size={20} className={`ml-auto transition-transform duration-300 ${isDashboardOpen ? 'rotate-180' : ''}`} />}
                            </button>
                            {isSidebarOpen && isDashboardOpen && (
                                <div className="pl-12 pr-4 py-2 flex flex-col space-y-1">
                                    <Link href={route('dashboardDigitalProduct')} className={`block px-4 py-2 text-sm rounded-md ${route().current('dashboardDigitalProduct') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'}`}>Dashboard Digital Product</Link>
                                    <Link href="#" className="block px-4 py-2 text-sm text-gray-400 cursor-not-allowed rounded-md">Dashboard SOS</Link>
                                </div>
                            )}
                        </div>

                        {/* Reports Dropdown */}
                        <div className="relative">
                            <button onClick={() => isSidebarOpen && setIsReportsOpen(!isReportsOpen)} className={`w-full flex items-center py-4 text-gray-600 hover:bg-gray-100 transition duration-300 text-left ${isSidebarOpen ? 'px-6' : 'justify-center'} ${isReportsActive ? 'bg-gray-200 text-gray-800 font-bold' : ''}`}>
                                <MdAssessment size={22} />
                                <span className={`ml-4 whitespace-nowrap transition-opacity duration-200 ${isSidebarOpen ? 'opacity-100' : 'opacity-0'}`}>Reports</span>
                                {isSidebarOpen && <MdKeyboardArrowDown size={20} className={`ml-auto transition-transform duration-300 ${isReportsOpen ? 'rotate-180' : ''}`} />}
                            </button>
                            {isSidebarOpen && isReportsOpen && (
                                <div className="pl-12 pr-4 py-2 flex flex-col space-y-1">
                                    {user.role === 'user' && (<>
                                        <Link href="#" className="block px-4 py-2 text-sm text-gray-400 cursor-not-allowed rounded-md">Aosodomoro</Link>
                                        <Link href={route('galaksi.index')} className={`block px-4 py-2 text-sm rounded-md ${route().current('galaksi.index') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'}`}>Galaksi</Link>
                                    </>)}
                                    {user.role === 'admin' && (<>
                                        <Link href={route('analysisDigitalProduct.index')} className={`block px-4 py-2 text-sm rounded-md ${route().current('analysisDigitalProduct.index') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'}`}>Report Digital Product</Link>
                                        <Link href="#" className="block px-4 py-2 text-sm text-gray-400 cursor-not-allowed rounded-md">Report SOS</Link>
                                    </>)}
                                </div>
                            )}
                        </div>
                    </>
                )}
            </nav>
            <UserProfile user={user} isSidebarOpen={isSidebarOpen} />
        </div>
    );
}

